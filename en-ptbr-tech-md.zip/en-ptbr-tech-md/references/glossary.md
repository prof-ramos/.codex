# Glossário de Termos Técnicos Mantidos em Inglês

Estes termos são mantidos em inglês conforme prática comum em PT-BR técnico:

- framework
- API
- backend
- frontend
- bug
- feature
- release
- cloud
- dataset
- prompt
- plugin
- widget
- dashboard
- cookie
- cache
- pipeline
- endpoint
- deployment
- roadmap
- stakeholder
- feedback
- node
- input
- workflow
- hotfix
- payload
